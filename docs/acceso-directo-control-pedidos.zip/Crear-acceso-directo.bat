@echo off
chcp 65001 >nul
title Control de Pedidos - Crear acceso directo
echo.
echo  Creando el acceso directo a Control de Pedidos en su escritorio...
echo.
set "DEST=%PUBLIC%\ControlPedidos"
if not exist "%DEST%" mkdir "%DEST%"
rem Se borra el icono de versiones anteriores (gris) para que Windows no lo reutilice
del /F /Q "%DEST%\Control-de-Pedidos.ico" >nul 2>&1
copy /Y "%~dp0Control-de-Pedidos-2.ico" "%DEST%\Control-de-Pedidos-2.ico" >nul
if errorlevel 1 (
  echo  No se ha encontrado el icono. Descomprima primero la carpeta completa y vuelva a ejecutar este archivo.
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$nl=[char]13+[char]10; $ico=Join-Path $env:PUBLIC 'ControlPedidos\Control-de-Pedidos-2.ico'; $txt='[InternetShortcut]'+$nl+'URL=https://proxy.controlpedidosprincess-canarias.workers.dev/'+$nl+'IconIndex=0'+$nl+'IconFile='+$ico+$nl; $dir=[Environment]::GetFolderPath('Desktop'); $f=Join-Path $dir 'Control de Pedidos.url'; if (Test-Path $f) { Remove-Item $f -Force }; [IO.File]::WriteAllText($f,$txt,[Text.Encoding]::Default)"
if errorlevel 1 (
  echo  Ha ocurrido un error al crear el acceso directo.
  pause
  exit /b 1
)
rem Refresca la cache de iconos de Windows
ie4uinit.exe -ClearIconCache >nul 2>&1
ie4uinit.exe -show >nul 2>&1
echo  Listo. Ya tiene el acceso directo "Control de Pedidos" en su escritorio.
echo  (Si el icono aun sale gris, pulse F5 en el escritorio o cierre sesion y vuelva a entrar.)
echo.
pause
